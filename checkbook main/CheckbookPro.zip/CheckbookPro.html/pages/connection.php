<?php
$conn = mysqli_connect("localhost","root","","checkbook");
if(!$conn)
{
    die ("database could not be connected!" );
}

?>
